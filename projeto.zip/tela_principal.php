<?php
	//<meta charset="utf-8">
    //<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   // <!-- Bootstrap CSS -->
	session_start();
	include("includes/conexao.php");
    function buildTableMovimentacao($serv)
	{
		$tabela = "<div class='col-sm-12'>
		<table id='movimentacaoTable'>
		<tr>
				<th>Tipo</td>
				<th>Valor</td>
				<th>Data</td>
				<th>Editores</th>
		</tr>";
		$contaId = getContaUsuario($_SESSION['userId'], $serv);
		$sqlValida = "SELECT data, valor, tipoMovimentacao_id, id FROM movimentacao where conta_id = '$contaId'";
		$query = mysqli_query($serv , $sqlValida); 
		while($query != null && $movimento = mysqli_fetch_array($query))
		{
			$tabela = $tabela."<tr>
				<td>".getTipoMovimentacao($movimento['tipoMovimentacao_id'])."</td>
				<td>".$movimento['valor']."</td>
				<td>".$movimento['data']."</td>
				<td> </td>
			</tr>";
		}	
		return $tabela;
	}	
	function getTipoMovimentacao($tipoMovimentacao)
	{
		$sqlValida = "SELECT codigo, caraterMovimento FROM movimentacao where id = '$tipoMovimentacao'";
		$query = mysqli_query($serv , $sqlValida); 
		$row = mysqli_fetch_assoc($query);
		$retorno = $row['codigo']; 
		if($row['caraterMovimento'] == 0)
		{
			$retorno = $retorno." - Saída ";
		}
		else 
		{
			$retorno = $retorno." - Entrada ";
		}
		return $retorno;
	}	
	function getContaUsuario($usuario, $serv)
	{
		$sqlUsuario = "SELECT id FROM conta where usuario_id = '$usuario'";
		$query = mysqli_query($serv , $sqlUsuario); 
		$row = mysqli_fetch_assoc($query);
		return $row['id']; 
	}	
	echo "<link rel='stylesheet' href='css/bootstrap.min.css'>";
	echo "<style>
		table {
		font-family: arial, sans-serif;
		border-collapse: collapse;
		width: 100%;
		}
		
		td, th {
		border: 1px solid #dddddd;
		text-align: left;
		padding: 8px;
		}
		
		tr:nth-child(even) {
		background-color: #dddddd;
		}
	</style>";
	echo "<body style='background-color:#C4F7FF;'>";
	echo "<div class='col-sm-12' id='header'>";
		echo "<label><strong>{$_SESSION['username']}</strong></label>";
	echo"</div>";
	echo"<div class='col-sm-12'>
		<button type='button' class='btn btn-success'>Adicionar Movimentação</button>
		<button type='button' class='btn btn-danger'>Parâmetros</button>
	</div>";
	echo"<div id='tabelaMovimentacao' >".buildTableMovimentacao($serv);
	echo"</div>";
	//echo "<script type='text/javascript'>";
	//echo "function adicionarMovimentacao(){
		
		//}
?>